function add_exercise_submit() {
  var name = $('#ExerciseName').val();
  var date = $('#ExerciseDate').val();
  var duration = $('#Duration').val();
  var name_len = name.length;
  var status = 1;
  if(name==''){
    alert('Name should not be empty');
    status = 0;
  }else if(name_len>100){
    alert('Exercise Name should not be greater than 100');
    status = 0;
  }

  if(date == ''){
    alert('Date should not be empty');
    status = 0;
  }

  if(duration == ''){
    alert('Duration should not be empty');
    status = 0;
  }else if(duration>120 || duration<1){
    alert('Duration should be between 1-120');
    status = 0;
  }

  if(status == 1){
    $.ajax({
      data:{ExerciseName:name,ExerciseDate:date,Duration:duration},
      type:"post",
      dataType:"json",
      url:"add_exercise.php",
      success:function(result){
        data = result;
        if(data['status'] == 0){
          alert(data['msg']); 
        }else if(data['status'] == 1){
          alert(data['msg']);
          $('#add_exercise_modal').modal('hide');
          location.reload(true);
          $('#view_link').click();
        }
      }
    });
  }
}
