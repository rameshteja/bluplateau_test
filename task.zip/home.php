<?php session_start();
?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Daily Exercise</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/freelancer.min.css" rel="stylesheet">
    <link href="css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">

  </head>

  <body id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg bg-secondary fixed-top text-uppercase" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">DAILY EXERCISE</a>
        <button class="navbar-toggler navbar-toggler-right text-uppercase bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fas fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item mx-0 mx-lg-1">
              <a class="btn btn-light rounded js-scroll-trigger" data-toggle="modal" data-target="#add_exercise_modal">Add Exercise</a>
            </li>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#" onclick="view_all();">View Exercise</a>
            </li>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="<?=$_SESSION['logout_url'];?>">Logout</a>
            </li>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded" href="#"><span class="btn btn-info btn-sm"><?php echo $_SESSION['userData']['first_name'];?></span></a>
              <!-- <?php
              echo "<pre>";
                echo $_SESSION['userData']['first_name'];
                print_r($_SESSION['userData']);
              ?> -->
            </li>
          </ul>
        </div>
      </div>
    </nav>
    <br>
    <section id="view_exercise" class="view_exercise">
      <div class="container">
        <div class="row">
          <div class="col-lg-12 text-center">
            <h2 class="section-heading">View Your Exercises</h2>
            <hr class="my-4">
          </div>
        </div>
      </div>
      <div class="container">
        <div class="row">
          <div class="col-md-3">
          </div>
          <div class="col-md-6">
            <nav class="navbar navbar-light bg-light ">
              <div class="form-inline">
              <!-- <form class="form-inline" method="post"> -->
                <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search" id="search_input" name="search_input">
                <button class="btn btn-outline-primary my-2 my-sm-0" onclick="ajax_search();">Search</button>
                <span id="view_all_btn"></span>
              <!-- </form> -->
              </div>
            </nav>
          </div>
          <div class="col-md-3">
          </div>
        </div>

        <div class="row">
          <div id="ajax_table" style="width: 100%;"></div>
          <table class="table table-hover border primary" id="default_table">
            <thead>
              <tr>
                <th scope="col">#</th>
                <th scope="col">Exercise Name</th>
                <th scope="col">Exercise DateTime</th>
                <th scope="col">Duration In Minutes</th>
                <th scope="col">Ations</th>
              </tr>
            </thead>
            <tbody>
              <?php
                $fb_id = $_SESSION['userData']['oauth_uid'];
                include'dbconnection.php';
                $query = mysqli_query($conn,"select * from records where fb_id='$fb_id'");
                if(mysqli_num_rows($query)!=0){
                  $i = 1;
                  while($row = mysqli_fetch_array($query)){
                  $id = $row['id'];
                    echo'
                      <tr>
                        <th scope="row">'.$i.'</th>
                        <td>'.$row["exercise_name"].'</td>
                        <td>'.$row["exercise_date"].'</td>
                        <td>'.$row["exercise_duration"].'</td>
                        <td>
                          <a href="edit.php?id='.$id.'" class="btn btn-info"><i class="fas fa-pencil-alt"></i>&nbsp</a>
                          <a href="delete.php?id='.$id.'" class="btn btn-danger"><i class="fas fa-trash-alt"></i></a>
                        </td>
                      </tr>
                    ';
                    $i++;
                  }
                }else{
                  echo "<tr><td colspan='4'>No Exercises!</td></tr>";
                }
              ?>
            </tbody>
          </table>
        </div>
      </div>
    </section>

    <!-- Add Exercise Modal -->
    <div class="modal fade" id="add_exercise_modal" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" >Add Exercise</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <form name="add_exercise_form" method="post">
              <div class="form-group">
                <label for="ExerciseName">Exercise Name</label>
                <input type="text" class="form-control" id="ExerciseName" name="ExerciseName" required="">
              </div>
              <div class="form-group">
                <label for="ExerciseDate">Exercise DateTime</label>
                <div class="controls input-append date form_datetime" data-date="2018-07-16T05:25:07Z" data-date-format="yyyy-mm-d H:i:s" data-link-field="dtp_input1">
                    <input size="16" type="text" class="form-control" value="" id="ExerciseDate" name="ExerciseDate" readonly>
                    <span class="add-on"><i class="icon-remove"></i></span>
                    <span class="add-on"><i class="icon-th"></i></span>
                </div>
                <input type="hidden" id="dtp_input1" value="" /><br/>
              </div>
              <div class="form-group">
                <label for="Duration">Duration</label>
                <input type="number" class="form-control" id="Duration" min="1" max="120" name="Duration" required="">
              </div>
            </form>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-primary" onclick="add_exercise_submit()">Add</button>
          </div>
        </div>
      </div>
    </div>

    <div class="copyright py-4 text-center text-white">
      <div class="container">
        <small>Copyright &copy; Your Website 2018</small>
      </div>
    </div>

    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-to-top d-lg-none position-fixed ">
      <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
        <i class="fa fa-chevron-up"></i>
      </a>
    </div>

    <!-- Portfolio Modals -->

    <!-- Portfolio Modal 1 -->
   <!--  <div class="portfolio-modal mfp-hide" id="portfolio-modal-1">
      <div class="portfolio-modal-dialog bg-white">
        <a class="close-button d-none d-md-block portfolio-modal-dismiss" href="#">
          <i class="fa fa-3x fa-times"></i>
        </a>
        <div class="container text-center">
          <div class="row">
            <div class="col-lg-8 mx-auto">
              <h2 class="text-secondary text-uppercase mb-0">Project Name</h2>
              <hr class="star-dark mb-5">
              <img class="img-fluid mb-5" src="img/portfolio/cabin.png" alt="">
              <p class="mb-5">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Mollitia neque assumenda ipsam nihil, molestias magnam, recusandae quos quis inventore quisquam velit asperiores, vitae? Reprehenderit soluta, eos quod consequuntur itaque. Nam.</p>
              <a class="btn btn-primary btn-lg rounded-pill portfolio-modal-dismiss" href="#">
                <i class="fa fa-close"></i>
                Close Project</a>
            </div>
          </div>
        </div>
      </div>
    </div> -->



    

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/scrollreveal/scrollreveal.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/creative.min.js"></script>

    <!-- Script to validate and call ajax on submit of add exercise -->
    <script src="js/validate.js"></script>
    <script src="js/ajax_search.js"></script>


<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="js/locales/bootstrap-datetimepicker.fr.js" charset="UTF-8"></script>
<script type="text/javascript">
    $('.form_datetime').datetimepicker({
        //language:  'fr',
        weekStart: 1,
        todayBtn:  1,
    autoclose: 1,
    todayHighlight: 1,
    startView: 2,
    forceParse: 0,
        showMeridian: 1
    });
  
</script>

  </body>

</html>
