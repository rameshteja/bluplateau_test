<?php  
	$search_input = trim($_POST['search_input']);

	$result = array();
	$result['status'] = 1;

	if($search_input==''){
		$result['status'] = 0;
		$result['name_msg'] = "Search should not be empty";
	}

	if($result['status'] == 1){
		//search to database
		include 'dbconnection.php';
		$query = mysqli_query($conn,"select * from records where exercise_name like '%$search_input%' ");
		if(mysqli_num_rows($query)!=0){
			$i=0;
			while($row = mysqli_fetch_array($query)){
				$result['data'][$i]['name'] = $row['exercise_name'];
				$result['data'][$i]['date'] = $row['exercise_date'];
				$result['data'][$i]['duration'] = $row['exercise_duration'];
				$i++;
			}
		}else{
			$result['status'] = 0;
			$result['message'] = "No Records Found !";
		}
	}

	echo json_encode($result);
?>