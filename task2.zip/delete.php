<?php
	include'dbconnection.php';
    $id = base64_decode($_GET['id']);
	if($id){
		$query = mysqli_query($conn,"select * from records where id='$id'");
		if(mysqli_num_rows($query)>0){
			$dquery = mysqli_query($conn,"delete from records where id='$id'");
			if($dquery){
				echo "<script>alert('Record deleted successfully');window.location='index.php'</script>";
				
			}
			else{
				echo "<script>alert('Fail to delete record please try again');window.location='index.php'</script>";
				
			}
		}else{
				echo "<script>alert('No data Found.. please try again..!');window.location='index.php'</script>";
		}
	}else{
				echo "<script>alert('select record');window.location='index.php'</script>";
	}
?>