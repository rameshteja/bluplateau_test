<?php 
	session_start(); 
	$name = $_POST['ExerciseName'];
	$date = $_POST['ExerciseDate'];
	$duration = $_POST['Duration'];
	

	$result = array();
	$result['status'] = 1;
	$result['msg'] = '';

	if($name==''){
		$result['status'] = 0;
		$result['msg'] .= "Name should not be empty,";
	}
	else if(strlen($name)>100){
	 	$result['status'] = 0;
	  	$result['msg'] .= "Exercise Name should not be greater than 100,";
	}

	if($date == ''){
		$result['status'] = 0;
	  	$result['msg'] .= "Date should not be empty,";
	}

	if($duration == ''){
		$result['status'] = 0;
	  	$result['msg'] .= "Duration should not be empty,";
	}
	else if($duration>120 || $duration<1){
		$result['status'] = 0;
	  	$result['msg'] .= "Duration should be between 1-120";
	}

	if($result['status'] == 1){
		//add to database
		include 'dbconnection.php';
		$check = mysqli_query($conn,"select exercise_name from records where exercise_name='$name'");
		if(mysqli_num_rows($check)==0){
			$query = mysqli_query($conn,"INSERT INTO `records`(`id`, `exercise_name`, `exercise_date`, `exercise_duration`) VALUES ('','$name','$date','$duration')");
			echo mysqli_error($conn);
			if($query){
				$result['msg'] = "Successfully Added";
			}else{
				$result['status'] = 0;
				$result['msg'] = "Failed to add";
			}
		}else{
			$result['status'] = 0;
			$result['msg'] = "Exercise Already Exists";
		}
	}

	echo json_encode($result);
?>