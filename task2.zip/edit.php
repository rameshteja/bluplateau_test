<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Daily Exercise</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css">

    <!-- Plugin CSS -->
    <link href="vendor/magnific-popup/magnific-popup.css" rel="stylesheet" type="text/css">

    <!-- Custom styles for this template -->
    <link href="css/freelancer.min.css" rel="stylesheet">
    <link href="css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">

  </head>

  <body id="page-top">

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg bg-secondary fixed-top text-uppercase" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">DAILY EXERCISE</a>
        <button class="navbar-toggler navbar-toggler-right text-uppercase bg-primary text-white rounded" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fas fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item mx-0 mx-lg-1">
              <a class="btn btn-light btn-xl js-scroll-trigger" data-toggle="modal" data-target="#add_exercise_modal">Add Exercise</a>
            </li>
            <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#" onclick="view_all();">View Exercise</a>
            </li>
            <!-- <li class="nav-item mx-0 mx-lg-1">
              <a class="nav-link py-3 px-0 px-lg-3 rounded js-scroll-trigger" href="#contact">Contact</a>
            </li> -->
          </ul>
        </div>
      </div>
    </nav>
    <br>
    <?php
    include'dbconnection.php';
    $id = base64_decode($_GET['id']);
    if(isset($_POST['edit'])){
      $name = $_POST['ExerciseName'];
      $date = $_POST['ExerciseDate'];
      $duration = $_POST['Duration'];
      $id = $_POST['id'];
      $check = mysqli_query($conn,"select * from records where id='$id'");
      if(mysqli_num_rows($check)>0){
        $query = mysqli_query($conn,"UPDATE `records` SET `exercise_name`='$name',`exercise_date`='$date',`exercise_duration`='$duration' WHERE id='$id'");
        echo mysqli_error($conn);
        if($query){
          echo "<script>alert('Updated successfully');window.location='index.php'</script>";
        }else{
           echo "<script>alert('Fail to update');window.location='index.php'</script>";
        }
      }else{
        echo mysqli_error($conn);exit();
        echo "<script>alert('No data found');window.location='index.php'</script>";
      }
    }
      
      
      $edit = mysqli_query($conn,"select * from records where id='$id'");
      $row = mysqli_fetch_array($edit);
    ?>
    <section id="contact">
      <div class="container">
        <h2 class="text-center text-uppercase text-secondary mb-0">Edit Daily Exercise</h2>
        <hr class="star-dark mb-5">
        <div class="row">
          <div class="col-lg-8 mx-auto">
           <form name="add_exercise_form" method="post" action="edit.php">
              <div class="form-group">
                <label for="ExerciseName">Exercise Name</label>
                <input type="text" class="form-control" id="ExerciseName" name="ExerciseName" required="" value="<?php echo $row['exercise_name']?>">
              </div>
              <div class="form-group">
                <label for="ExerciseDate">Exercise DateTime</label>
                <div class="controls input-append date form_datetime" data-date="2018-07-16T05:25:07Z" data-date-format="yyyy-mm-d H:i:s" data-link-field="dtp_input1">
                    <input size="16" type="text" class="form-control" id="ExerciseDate" name="ExerciseDate" readonly value="<?php echo $row['exercise_date']?>">
                    <span class="add-on"><i class="icon-remove"></i></span>
                    <span class="add-on"><i class="icon-th"></i></span>
                </div>
                <input type="hidden" id="dtp_input1" value="" /><br/>
              </div>
              <div class="form-group">
                <label for="Duration">Duration</label>
                <input type="number" class="form-control" id="Duration" min="1" max="120" name="Duration" required="" value="<?php echo $row['exercise_duration']?>">
                <input type="hidden" name="id" value="<?php echo $id;?>">
              </div>
              <div class="form-group">
                
                <button type="submit" class="btn btn-success" id="" min="1" max="120" name="edit"onsubmit="valid();">Edit</button>
                <a href="index.php" class="btn btn-primary">Back</a>
              </div>
            </form>
          </div>
        </div>
      </div>
    </section>

    <div class="copyright py-4 text-center text-white">
      <div class="container">
        <small>Copyright &copy; Your Website 2018</small>
      </div>
    </div>

    <!-- Scroll to Top Button (Only visible on small and extra-small screen sizes) -->
    <div class="scroll-to-top d-lg-none position-fixed ">
      <a class="js-scroll-trigger d-block text-center text-white rounded" href="#page-top">
        <i class="fa fa-chevron-up"></i>
      </a>
    </div>
    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Plugin JavaScript -->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="vendor/scrollreveal/scrollreveal.min.js"></script>
    <script src="vendor/magnific-popup/jquery.magnific-popup.min.js"></script>

    <!-- Custom scripts for this template -->
    <script src="js/creative.min.js"></script>

    <!-- Script to validate and call ajax on submit of add exercise -->
    <script src="js/validate.js"></script>
    <script src="js/ajax_search.js"></script>


<script type="text/javascript" src="js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
<script type="text/javascript" src="js/locales/bootstrap-datetimepicker.fr.js" charset="UTF-8"></script>
<script type="text/javascript">
    $('.form_datetime').datetimepicker({
        //language:  'fr',
        weekStart: 1,
        todayBtn:  1,
    autoclose: 1,
    todayHighlight: 1,
    startView: 2,
    forceParse: 0,
        showMeridian: 1
    });
  
</script>
<script>
  function valid(){
    // alert('ok');
     var name = $('#ExerciseName').val();
     var date = $('#ExerciseDate').val();
     var duration = $('#Duration').val();
     var id = '<?php echo $id;?>';
     var name_len = name.length;
    var status = 1;
    if(name==''){
      alert('Name should not be empty');
      status = 0;
    }else if(name_len>100){
      alert('Exercise Name should not be greater than 100');
      status = 0;
    }

    if(date == ''){
      alert('Date should not be empty');
      status = 0;
    }

    if(duration == ''){
      alert('Duration should not be empty');
      status = 0;
    }else if(duration>120 || duration<1){
      alert('Duration should be between 1-120');
      status = 0;
    }

    if(status == 1){
      $.ajax({
        data:{ExerciseName:name,ExerciseDate:date,Duration:duration,id:id},
        type:"post",
        dataType:"json",
        url:"edit_exercise.php",
        success:function(result){
          data = result;
          if(data['status'] == 0){
            alert(data['msg']); 
          }else if(data['status'] == 1){
            alert(data['msg']);
            $('#add_exercise_modal').modal('hide');
            location.reload(true);
            $('#view_link').click();
          }
        }
      });
    }
  }
</script>
  </body>

</html>
