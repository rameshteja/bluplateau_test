function view_all(){
	$('#ajax_output').remove();
	$('#default_table').show();
	
}

function ajax_search() {
	var search_input = $('#search_input').val();
	if(search_input==''){
		alert('Input and Search Again');
	}else{
		//search valid
		//hide default table
		$('#default_table').hide();
		//call ajax for search and append table
		$.ajax({
			data:{search_input:search_input},
			type:"post",
			dataType:"json",
			url:"ajax_search.php",
			success:function(result){
				data = result;
				if(data['status']==0){
					$('#ajax_output').remove();
					$('#v_btn').remove();
					
					$('#ajax_table').append('<table class="table table-hover" id="ajax_output"><thead> <tr> <th scope="col">#</th> <th scope="col">Exercise Name</th> <th scope="col">Exercise DateTime</th> <th scope="col">Duration In Minutes</th> </tr> </thead> <tbody> <tr><td colspan="4" style="text-align:center;">'+data["message"]+'</td></tr> </tbody> </table>');
				}else{
					$('#ajax_output').remove();
					$('#v_btn').remove();
					
					$('#ajax_table').append('<table class="table table-hover" id="ajax_output"> <thead> <tr> <th scope="col">#</th> <th scope="col">Exercise Name</th> <th scope="col">Exercise DateTime</th> <th scope="col">Duration In Minutes</th> </tr> </thead> <tbody id="search_body"></tbody> </table>');
					var j=1;
					for (i = 0; i < data['data'].length; i++) { 
						$('#search_body').append('<tr> <th scope="row">'+j+'</th> <td>'+data['data'][i]["name"]+'</td> <td>'+data['data'][i]["date"]+'</td> <td>'+data['data'][i]["duration"]+'</td> </tr>');
						j++;
					}
				}
			}
		});
	}
}